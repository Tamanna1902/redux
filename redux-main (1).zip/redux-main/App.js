// src/App.js
import React from 'react';
import Todo from './Todo';

const App = () => {
  return (
    <div>
      <Todo />
    </div>
  );
};

export default App;
